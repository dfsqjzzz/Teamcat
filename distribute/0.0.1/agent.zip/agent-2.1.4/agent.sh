java -jar libs/teamcat-agent-2.1.4.jar
